package com.example.hexagonaled.bitcouponseller.Service;

import android.content.Intent;

import android.support.v4.content.LocalBroadcastManager;
import android.util.Log;

import com.example.hexagonaled.bitcouponseller.Common.Config;
import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

import static android.content.ContentValues.TAG;

/**
 * Created by hexagonaled on 02/05/2018.
 */

public class BitcouponFirebaseMessagingService extends FirebaseMessagingService {
    public void onMessageReceived(RemoteMessage remoteMessage){
        //super.onMessageReceived(remoteMessage);
        Log.d(TAG,"onMessageReceived");
        handleMessage(remoteMessage.getData().get(Config.STR_KEY));
    }

    private void handleMessage(String message){
        Intent pushNotification = new Intent(Config.STR_PUSH);
        pushNotification.putExtra(Config.STR_MESSAGE,message);
        LocalBroadcastManager.getInstance(this).sendBroadcast(pushNotification);
    }
}
