package com.example.hexagonaled.bitcouponseller.Common;

/**
 * Created by hexagonaled on 02/05/2018.
 */

public class Config {
    public static final String STR_PUSH = "pushNotification";
    public static final String STR_KEY = "webURL";
    public static final String STR_MESSAGE = "message";


}
